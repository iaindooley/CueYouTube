Go to http://code.google.com/p/bitly/ for installation
instructions and usage examples.
